#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js is not installed. Download it from https://nodejs.org"; exit 1; }
( sleep 2; (command -v xdg-open >/dev/null && xdg-open http://localhost:3000) || (command -v open >/dev/null && open http://localhost:3000) ) >/dev/null 2>&1 &
node server.js
