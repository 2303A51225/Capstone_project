@echo off
title Claims Desk
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Download it from https://nodejs.org and run this again. & pause & exit /b)
start "" cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:3000"
echo Starting Claims Desk. Keep this window open while you use the website.
node server.js
pause
