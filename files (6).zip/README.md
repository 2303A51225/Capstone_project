# Claims Desk: motor insurance claims website (frontend + backend)

A complete website with a real backend. No `npm install` is needed: the server uses only what Node.js ships with.

## What is inside

| Path | What it is |
|---|---|
| `server.js` | The backend: web server, login, sessions, permissions and data storage |
| `check.js` | Checks a running site and tells you what is wrong (`node check.js http://localhost:3000`) |
| `manage-users.js` | Add admins, add customers, change passwords from the command line |
| `public/index.html` | The frontend page |
| `public/css/styles.css` | Styling |
| `public/js/app.js` | Frontend logic (claims, approvals, AI photo check, PDFs) |
| `public/js/data.js` | Built-in claims data used for charts and checks |
| `public/data/claims_dataset.csv` | The same data as a spreadsheet |
| `start.bat` / `start.sh` | One-click start for Windows / Mac and Linux |
| `DEPLOY.md` | Step-by-step guide to put the site online (Docker, VPS, Render, Railway, Fly) |
| `Dockerfile`, `docker-compose.yml`, `Procfile`, `render.yaml`, `deploy/` | Ready-made deployment files (systemd service, Caddy and nginx configs) |
| `.env.example` | The settings to fill in when deploying |
| `package.json` | Lets you start with `npm start` |
| `storage/` | Created on first run. Holds `db.json` (all claims, complaints, approvals) and `users.json` (logins). **Back this folder up.** |

## Run it

1. Install Node.js (version 16 or newer) from https://nodejs.org
2. Double-click `start.bat` (Windows), or run `./start.sh` (Mac/Linux), or run `node server.js`
3. Open http://localhost:3000

Demo logins, created on first run: **admin / Admin@123** and **customer / Customer@123**.

New customers can create their own login on the sign-in page: type a new username and password, then confirm the password.

## What the backend does

- **Shared data:** every customer and admin sees the same live data. Open the site on two browsers and the admin sees a claim as soon as a customer files it (it refreshes every few seconds).
- **Real logins:** passwords are hashed with scrypt on the server. Sessions last 12 hours. Five wrong passwords lock that login for 30 seconds.
- **Permissions enforced on the server** (not just hidden in the page):
  - A customer can read and write only their own claims, complaints and insurance applications.
  - Only an admin can verify or approve a claim, decide an application, or reply to a complaint.
  - A customer sees only the decisions and replies on their own items.
  - Admin accounts cannot be created from the website. Use `manage-users.js`.
- **AI photo check:** runs in the browser when a customer picks damage photos, so it works offline. Its result is saved with the claim for the admin.
- **Damage photos are required** to file a claim.
- **Approval forms** (claim approval letter, policy certificate) include the company logo and the approved date and time.

## Manage logins

```
node manage-users.js list
node manage-users.js add-admin    meera  S0meStr0ngPass
node manage-users.js add-customer ravi   An0therPass1
node manage-users.js passwd       admin  NewAdminPassword
node manage-users.js remove       ravi
```

**Change the demo passwords before you share the site with anyone.** To start without demo logins at all, set `NO_DEMO=1` before the first run, then add your own admin.

**Going online?** Read `DEPLOY.md`. It must be hosted somewhere that runs Node.js (not a static-only host). After deploying, run `node check.js https://your-site` to confirm everything works.

## Settings (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Port to listen on |
| `ADMIN_USER`, `ADMIN_PASSWORD` | unset | Creates your own admin on first start and skips the demo logins |
| `TRUST_PROXY` | unset | Set to `1` behind a proxy or hosting platform |
| `HOST` | 127.0.0.1 (0.0.0.0 when `PORT` is set) | Use `0.0.0.0` so phones and other computers on your Wi-Fi can open it at `http://<your-computer-ip>:3000` |
| `STORAGE_DIR` | `./storage` | Where data and logins are kept |
| `NO_DEMO` | unset | Set to `1` to skip creating demo logins |

Example: `HOST=0.0.0.0 PORT=8080 node server.js` (on Windows: `set HOST=0.0.0.0` then `node server.js`).

## Without the backend

If you open `public/index.html` directly (double-click), the site still works on its own. Data is then saved only in that browser, and a yellow note says so. Everything else, including the offline AI photo check, works.

## Good to know

- Data is kept in simple JSON files. That is fine for a demo or a small team. For many thousands of customers, move the storage to a database such as PostgreSQL.
- Photos are stored inside the claim data as compressed images, so `db.json` grows as claims are filed.
- Use HTTPS (for example behind a reverse proxy such as Caddy or nginx) before putting this on the public internet.
- With no internet, fonts fall back to defaults and approval forms download as a printable web page instead of a PDF. The PDF library loads from the internet when available.
- The approval documents are demo documents and not legal insurance policies.
