/* Check a running Claims Desk website and say what is wrong.
   Usage:  node check.js http://localhost:3000
           node check.js https://claims.example.com                                      */
'use strict';
const base = (process.argv[2] || 'http://localhost:3000').replace(/\/+$/, '');
const ok = m => console.log('  OK    ' + m), bad = m => console.log('  FAIL  ' + m);
async function get(p, o) { try { const r = await fetch(base + p, { redirect: 'manual', ...o }); return { s: r.status, t: await r.text(), h: r.headers } } catch (e) { return { err: e.message } } }
(async () => {
  console.log('Checking ' + base + '\n');
  const home = await get('/');
  if (home.err) return bad('Cannot reach the site (' + home.err + '). Is the server running, and is the address and port right?');
  home.s === 200 && /Claims Desk/.test(home.t) ? ok('Home page loads') : bad('Home page returned ' + home.s + ' and not the Claims Desk page. The host may be serving the wrong folder.');
  for (const f of ['/js/app.js', '/js/data.js', '/css/styles.css']) { const r = await get(f); r.s === 200 ? ok(f + ' loads') : bad(f + ' returned ' + (r.err || r.s) + '. Upload the whole "public" folder with its subfolders.') }
  const ping = await get('/api/ping'); let j = null; try { j = JSON.parse(ping.t) } catch (e) { }
  if (j && j.app === 'claims-desk') ok('Backend is running (/api/ping)');
  else bad('Backend NOT found at /api/ping (got ' + (ping.err || ping.s) + '). The files are being served as a plain static site, so customers and admins will NOT share data. Run server.js on a Node.js host (see DEPLOY.md).');
  const hz = await get('/healthz'); hz.s === 200 ? ok('Health check /healthz') : bad('/healthz returned ' + (hz.err || hz.s));
  const lg = await get('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'check-user-that-does-not-exist', password: 'x', role: 'admin' }) });
  let lj = null; try { lj = JSON.parse(lg.t) } catch (e) { }
  lj && lj.ok === false ? ok('Login endpoint answers correctly') : bad('Login endpoint did not answer like Claims Desk (status ' + (lg.err || lg.s) + '). A proxy may be blocking POST requests or the /api path.');
  if (base.startsWith('http://') && !/localhost|127\.0\.0\.1|192\.168\.|10\./.test(base)) console.log('  WARN  This address uses plain http. Use https before real customers upload Aadhaar or PAN photos.');
  if (home.h && !home.h.get('x-content-type-options')) console.log('  NOTE  Security headers not seen (normal if a proxy strips them).');
  console.log('\nDone.');
})();
