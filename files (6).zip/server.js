/* Claims Desk backend: zero-dependency Node.js server.
   - Serves the website from ./public
   - REST API under /api (login, sessions, documents) with role based permissions
   - Stores data in ./storage/db.json and ./storage/users.json
   Run:  node server.js     then open http://localhost:3000                      */
'use strict';
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
if (+process.versions.node.split('.')[0] < 16) { console.error('Claims Desk needs Node.js 16 or newer (you have ' + process.versions.node + '). Download the current version from https://nodejs.org'); process.exit(1) }

const PORT = +process.env.PORT || 3000;
const HOST = process.env.HOST || (process.env.PORT ? '0.0.0.0' : '127.0.0.1'); // cloud hosts set PORT, so listen on all addresses there
const TRUST_PROXY = process.env.TRUST_PROXY === '1';      // set to 1 when running behind nginx, Caddy, Render, Railway, Fly...
const PUB = path.join(__dirname, 'public');
const STORE = process.env.STORAGE_DIR ? path.resolve(process.env.STORAGE_DIR) : path.join(__dirname, 'storage');
const DB_FILE = path.join(STORE, 'db.json'), USERS_FILE = path.join(STORE, 'users.json');
if (!fs.existsSync(path.join(PUB, 'index.html'))) { console.error('Cannot find the website files at ' + PUB + '\nKeep server.js next to the "public" folder (do not move server.js on its own).'); process.exit(1) }
const MAX_BODY = 40 * 1024 * 1024, SESSION_MS = 12 * 3600 * 1000;
fs.mkdirSync(STORE, { recursive: true });

/* ---------- users ---------- */
const hashPw = (pw, salt) => new Promise((res, rej) => crypto.scrypt(pw, salt, 64, (e, k) => e ? rej(e) : res(k.toString('hex'))));
const safeEq = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && crypto.timingSafeEqual(x, y) };
let users = {}, usersMtime = 0;
function loadUsers() {
  try { const st = fs.statSync(USERS_FILE); if (st.mtimeMs === usersMtime) return; users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8')); usersMtime = st.mtimeMs }
  catch (e) { if (e.code !== 'ENOENT') console.error('Could not read users.json:', e.message) }
}
function saveUsers() { const t = USERS_FILE + '.tmp'; fs.writeFileSync(t, JSON.stringify(users, null, 2)); fs.renameSync(t, USERS_FILE); usersMtime = fs.statSync(USERS_FILE).mtimeMs }
async function addUser(username, password, role) {
  const salt = crypto.randomBytes(16).toString('hex');
  users[username] = { uid: 'u' + crypto.randomBytes(8).toString('hex'), role, salt, hash: await hashPw(password, salt), created: Date.now() };
  saveUsers(); return users[username];
}
async function seed() {
  loadUsers();
  const AU = String(process.env.ADMIN_USER || '').trim().toLowerCase(), AP = process.env.ADMIN_PASSWORD || '';
  if (AU && AP) {
    if (!/^[a-z0-9._-]{3,32}$/.test(AU) || AP.length < 8) console.error('ADMIN_USER must be 3-32 letters/numbers and ADMIN_PASSWORD at least 8 characters. Admin not created.');
    else if (!users[AU]) { await addUser(AU, AP, 'admin'); console.log('Created admin login "' + AU + '" from ADMIN_USER / ADMIN_PASSWORD.') }
  }
  if (!Object.keys(users).length && process.env.NO_DEMO !== '1' && !AU) {
    await addUser('admin', 'Admin@123', 'admin'); await addUser('customer', 'Customer@123', 'customer');
    console.log('Created demo logins: admin / Admin@123 and customer / Customer@123 (change them with: node manage-users.js)');
  }
}

/* ---------- document store ---------- */
let store = {}, rev = 1, dirty = null;
try { store = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')) } catch (e) { if (e.code !== 'ENOENT') console.error('Could not read db.json:', e.message) }
function flush() { dirty = null; const t = DB_FILE + '.tmp'; fs.writeFileSync(t, JSON.stringify(store)); fs.renameSync(t, DB_FILE) }
const persist = () => { if (!dirty) dirty = setTimeout(flush, 150) };
['SIGINT', 'SIGTERM'].forEach(s => process.on(s, () => { try { flush() } catch (e) { } process.exit(0) }));

/* ---------- permissions ---------- */
const SEG = /^[A-Za-z0-9_.-]{1,80}$/, ROOTS = new Set(['claims', 'complaints', 'applications', 'verifications', 'aichecks']);
const validPath = p => typeof p === 'string' && p.length < 400 && p.split('/').every(s => SEG.test(s)) && p.split('/').length <= 4 && ROOTS.has(p.split('/')[0]);
const ownIds = uid => ((store['claims/' + uid] || {}).items || []).map(i => i && i.id);
/* returns true if the session may read (op 'r') or write (op 'w') this document path */
function allowed(s, op, p) {
  const seg = p.split('/'), root = seg[0], admin = s.role === 'admin';
  if (root === 'claims' || root === 'complaints' || root === 'applications') {
    if (seg.length === 2) return op === 'r' ? (admin || seg[1] === s.uid) : (!admin && seg[1] === s.uid);
    if (seg.length === 4 && (seg[2] === 'replies' || seg[2] === 'decisions') && seg[2] === (root === 'complaints' ? 'replies' : root === 'applications' ? 'decisions' : '-'))
      return op === 'r' ? (admin || seg[1] === s.uid) : admin;
    return false;
  }
  if (root === 'verifications' && seg.length === 2) return op === 'r' ? (admin || ownIds(s.uid).includes(seg[1])) : admin;
  if (root === 'aichecks' && seg.length === 2) return op === 'r' ? admin : (admin || ownIds(s.uid).includes(seg[1]));
  return false;
}
/* every NEW damage claim or insurance application must carry at least 4 photos */
function photoRule(p, d) {
  if (!/^(claims|applications)\/[^/]+$/.test(p) || !Array.isArray(d.items)) return null;
  const old = ((store[p] || {}).items || []).map(i => i && i.id);
  for (const i of d.items) { if (!i || old.includes(i.id) || i.type === 'nominee') continue; if (!Array.isArray(i.photos) || i.photos.length < 4) return 'Add at least 4 photos from different angles.' }
  return null;
}
const sane = (p, d) => d && typeof d === 'object' && !Array.isArray(d) && (!/^(claims|complaints|applications)\/[^/]+$/.test(p) || Array.isArray(d.items));

/* ---------- sessions and login throttling ---------- */
const sessions = new Map(), fails = new Map();
const newSession = (u, username) => { const t = crypto.randomBytes(32).toString('hex'); sessions.set(t, { uid: u.uid, role: u.role, username, exp: Date.now() + SESSION_MS }); return t };
function auth(req) {
  const m = /^Bearer ([a-f0-9]{64})$/.exec(req.headers.authorization || ''), s = m && sessions.get(m[1]);
  if (!s) return null; if (s.exp < Date.now()) { sessions.delete(m[1]); return null } s.token = m[1]; return s;
}
setInterval(() => { const n = Date.now(); sessions.forEach((s, t) => s.exp < n && sessions.delete(t)); fails.forEach((f, k) => f.until < n && f.n < 5 && fails.delete(k)) }, 600000).unref();

/* ---------- http helpers ---------- */
const send = (res, code, obj) => { const b = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(b) }); res.end(b) };
function body(req) {
  return new Promise((res, rej) => { let n = 0; const c = [];
    req.on('data', d => { n += d.length; if (n > MAX_BODY) { rej(Object.assign(new Error('Request too large'), { code: 413 })); req.destroy() } else c.push(d) });
    req.on('end', () => { try { res(c.length ? JSON.parse(Buffer.concat(c).toString('utf8')) : {}) } catch (e) { rej(Object.assign(new Error('Invalid JSON'), { code: 400 })) } });
    req.on('error', rej) });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.csv': 'text/csv; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.md': 'text/markdown; charset=utf-8', '.txt': 'text/plain; charset=utf-8' };
const SEC = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'no-referrer' };
const secHeaders = req => TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https' ? { ...SEC, 'Strict-Transport-Security': 'max-age=31536000' } : SEC;

const clientIp = req => (TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '';
/* ---------- API ---------- */
async function api(req, res, url) {
  const r = url.pathname;
  if (r === '/api/ping' && req.method === 'GET') return send(res, 200, { app: 'claims-desk', ok: true });

  if (r === '/api/login' && req.method === 'POST') {
    const b = await body(req), username = String(b.username || '').trim().toLowerCase(), pw = String(b.password || ''), role = b.role === 'admin' ? 'admin' : 'customer';
    const key = clientIp(req) + '|' + username, f = fails.get(key) || { n: 0, until: 0 };
    if (f.until > Date.now()) return send(res, 429, { ok: false, error: 'Too many wrong attempts. Wait 30 seconds and try again.' });
    if (!username || !pw) return send(res, 400, { ok: false, error: 'Enter your username and password.' });
    loadUsers();
    let u = users[username];
    if (!u) {
      if (role === 'admin') return send(res, 403, { ok: false, error: 'Admin accounts are created by the site owner (see manage-users.js).' });
      if (b.confirm === undefined) return send(res, 200, { ok: false, code: 'new' });
      if (!/^[a-z0-9._-]{3,32}$/.test(username)) return send(res, 400, { ok: false, error: 'Username must be 3 to 32 letters, numbers, dot, dash or underscore.' });
      if (pw.length < 8) return send(res, 400, { ok: false, error: 'Use a password with at least 8 characters.' });
      if (pw !== String(b.confirm)) return send(res, 400, { ok: false, error: 'The two passwords do not match.' });
      u = await addUser(username, pw, 'customer');
    } else {
      const ok = safeEq(await hashPw(pw, u.salt), u.hash);
      if (!ok) { f.n++; if (f.n >= 5) { f.until = Date.now() + 30000; f.n = 0 } fails.set(key, f); return send(res, 401, { ok: false, error: 'Wrong username or password.' }) }
      if (u.role !== role) return send(res, 403, { ok: false, error: role === 'admin' ? 'This account does not have admin access. Choose Customer.' : 'This is an admin account. Choose Admin.' });
      fails.delete(key);
    }
    return send(res, 200, { ok: true, token: newSession(u, username), uid: u.uid, role: u.role, username });
  }

  const s = auth(req);
  if (!s) return send(res, 401, { ok: false, error: 'Please sign in again.' });
  if (r === '/api/logout' && req.method === 'POST') { sessions.delete(s.token); return send(res, 200, { ok: true }) }
  if (r === '/api/me' && req.method === 'GET') return send(res, 200, { ok: true, uid: s.uid, role: s.role, username: s.username });

  if (r === '/api/doc') {
    const p = url.searchParams.get('path') || '';
    if (req.method === 'GET') {
      if (!validPath(p) || !allowed(s, 'r', p)) return send(res, 403, { ok: false, error: 'Not allowed.' });
      return send(res, 200, { ok: true, exists: p in store, data: store[p] === undefined ? null : store[p] });
    }
    if (req.method === 'PUT') {
      const b = await body(req), pp = String(b.path || '');
      if (!validPath(pp) || !allowed(s, 'w', pp)) return send(res, 403, { ok: false, error: 'You are not allowed to change this.' });
      const need = photoRule(pp, b.data); if (need) return send(res, 400, { ok: false, error: need });
      if (!sane(pp, b.data)) return send(res, 400, { ok: false, error: 'Invalid data.' });
      store[pp] = b.data; rev++; persist(); return send(res, 200, { ok: true, rev });
    }
  }
  if (r === '/api/collection' && req.method === 'GET') {
    const p = url.searchParams.get('path') || '';
    if (!p.split('/').every(x => SEG.test(x)) || !ROOTS.has(p.split('/')[0])) return send(res, 200, { ok: true, rev, docs: [] });
    if (url.searchParams.get('rev') === String(rev)) return send(res, 200, { ok: true, rev, unchanged: true });
    const n = p.split('/').length, docs = [];
    for (const k in store) if (k.startsWith(p + '/') && k.split('/').length === n + 1 && allowed(s, 'r', k)) docs.push({ id: k.split('/').pop(), data: store[k] });
    return send(res, 200, { ok: true, rev, docs });
  }
  return send(res, 404, { ok: false, error: 'Not found.' });
}

/* ---------- static files ---------- */
function serve(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end() }
  let p; try { p = decodeURIComponent(url.pathname) } catch (e) { res.writeHead(400); return res.end() }
  if (p.endsWith('/')) p += 'index.html';
  const f = path.normalize(path.join(PUB, p));
  if (f !== PUB && !f.startsWith(PUB + path.sep)) { res.writeHead(403); return res.end('Forbidden') }
  fs.stat(f, (e, st) => {
    if (e || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found') }
    res.writeHead(200, { ...secHeaders(req), 'Content-Type': MIME[path.extname(f).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-cache' });
    if (req.method === 'HEAD') return res.end(); fs.createReadStream(f).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try { if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok') }
    if (url.pathname.startsWith('/api/')) { Object.entries(secHeaders(req)).forEach(([k, v]) => res.setHeader(k, v)); await api(req, res, url) } else serve(req, res, url) }
  catch (e) { if (!res.headersSent) send(res, e.code === 413 || e.code === 400 ? e.code : 500, { ok: false, error: e.code ? e.message : 'Server error.' }); if (!e.code) console.error(e) }
});
server.on('error', e => { console.error(e.code === 'EADDRINUSE' ? '\nPort ' + PORT + ' is already in use. Close the other copy of Claims Desk, or start on another port, for example:  PORT=3001 node server.js   (Windows: set PORT=3001 then node server.js)' : '\nCould not start: ' + e.message); process.exit(1) });
seed().then(() => server.listen(PORT, HOST, () => {
  console.log('\nClaims Desk is running.\n  Open  http://' + (HOST === '0.0.0.0' ? 'localhost' : HOST) + ':' + PORT + '\n  Data  ' + STORE + '\n  Stop  press Ctrl+C\n');
}));
