# Deploying Claims Desk

Claims Desk is one Node.js program (`server.js`) with no dependencies. Anything that can run Node.js 18 or newer, or a Docker container, can host it.

## Read this first: pick a host that can run Node.js

Claims Desk has a backend (`server.js`). It must run on a host that runs Node.js or Docker (Options 1 to 3 below).

**Static hosts cannot run it.** Netlify drag-and-drop, GitHub Pages, Firebase Hosting (hosting only), Vercel static, and PHP-only hosting just serve the files in `public/`. The pages open and look right, but there is no server, so every browser keeps its own private data: **an admin will not see what a customer files.** If you open the site and see the yellow note "running without its backend", this is why. Move it to a Node.js host.

Once it is online, check it from any computer that has Node.js:

```bash
node check.js https://your-site-address
```

It tells you in plain words which part is missing (for example "Backend NOT found").

## Before you go live (checklist)

1. **Set your own admin login.** Set `ADMIN_USER` and `ADMIN_PASSWORD` (at least 8 characters, use a long one). When they are set, the demo logins (`admin / Admin@123`, `customer / Customer@123`) are **not** created.
2. **Use HTTPS.** Logins and Aadhaar/PAN photos must never travel over plain HTTP. Every option below gives you HTTPS.
3. **Keep data on a persistent disk.** All claims, photos and logins live in the folder set by `STORAGE_DIR`. If that folder is wiped (for example on a host with a temporary disk), everything is lost.
4. **Set `TRUST_PROXY=1`** when a proxy or platform sits in front of the app (every option below except running Node directly). It lets the login lockout see each visitor's real address and turns on HSTS.
5. **Back up the storage folder** (see Backups).

> This app stores personal data (names, mobile numbers, addresses, Aadhaar and PAN images). Before real customers use it, check the legal and privacy rules that apply to you (for example India's DPDP Act) and who is allowed to see the data.

## Environment variables

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Port to listen on. Hosting platforms set this for you. |
| `HOST` | `0.0.0.0` when `PORT` is set, otherwise `127.0.0.1` | Address to listen on |
| `STORAGE_DIR` | `./storage` | Folder for `db.json` and `users.json`. Point it at a persistent disk. |
| `ADMIN_USER`, `ADMIN_PASSWORD` | unset | Creates this admin on first start (skipped if the name already exists). Disables the demo logins. |
| `NO_DEMO` | unset | `1` skips the demo logins even without `ADMIN_USER` |
| `TRUST_PROXY` | unset | `1` when behind a proxy or platform |

Health check address for monitors: `/healthz` (answers `ok`).

---

## Option 1: Docker (works on any server or laptop)

```bash
cp .env.example .env        # then edit ADMIN_USER and ADMIN_PASSWORD
docker compose up -d --build
```

Open http://localhost:3000. Data is kept in the Docker volume `claims-data` (mounted at `/data`). Put HTTPS in front with Caddy or nginx (Option 2, step 5), or use a platform that adds it.

Without compose:

```bash
docker build -t claims-desk .
docker run -d --name claims-desk -p 3000:3000 -v claims-data:/data \
  -e ADMIN_USER=admin -e ADMIN_PASSWORD='your-long-password' claims-desk
```

## Option 2: Your own Ubuntu or Debian server (VPS)

1. Install Node.js 18 or newer (for example from https://nodejs.org or `apt install nodejs`).
2. Copy this folder to the server as `/opt/claims-desk` (`scp`, `rsync` or `git clone`).
3. Create the data folder and give the service user access:
   ```bash
   sudo mkdir -p /var/lib/claims-desk && sudo chown www-data /var/lib/claims-desk
   sudo chown -R www-data /opt/claims-desk
   ```
4. Install the service. Edit `ADMIN_PASSWORD` in `deploy/claims-desk.service` first, then:
   ```bash
   sudo cp deploy/claims-desk.service /etc/systemd/system/
   sudo systemctl daemon-reload && sudo systemctl enable --now claims-desk
   sudo systemctl status claims-desk
   ```
5. Add HTTPS with Caddy (simplest, certificates are automatic). Point your domain's DNS at the server, edit the domain in `deploy/Caddyfile`, then:
   ```bash
   sudo apt install caddy
   sudo cp deploy/Caddyfile /etc/caddy/Caddyfile && sudo systemctl reload caddy
   ```
   Prefer nginx? Use `deploy/nginx.conf` and `sudo certbot --nginx -d your-domain`.
6. Open https://your-domain.

## Option 3: Render, Railway, Fly.io and similar platforms

The settings are the same everywhere:

- **Start command:** `node server.js` (there is nothing to build, so leave the build command empty). A `Dockerfile`, a `Procfile` and a `render.yaml` are included.
- **Environment variables:** `ADMIN_USER`, `ADMIN_PASSWORD`, `TRUST_PROXY=1`, `STORAGE_DIR=/data`.
- **Persistent disk or volume** mounted at `/data`. This is required. On Render a disk needs a paid plan; on Railway add a Volume; on Fly.io run `fly volumes create data` and mount it at `/data`. Platforms that give you a temporary disk will lose all data on each restart or redeploy.
- **Health check path:** `/healthz`
- HTTPS and your domain are provided by the platform.
- Run **one** instance only. The app keeps data in one file, so it cannot be scaled across several copies.

## Backups

Everything is in the storage folder. To back up, copy `db.json` and `users.json`:

```bash
cp /var/lib/claims-desk/db.json  ~/backup/db-$(date +%F).json
cp /var/lib/claims-desk/users.json ~/backup/users-$(date +%F).json
```

To restore, stop the app, put the two files back in the storage folder and start it again. Schedule the copy daily (for example with `cron`) and keep copies somewhere other than the server.

## Managing logins on the server

```bash
STORAGE_DIR=/var/lib/claims-desk node manage-users.js list
STORAGE_DIR=/var/lib/claims-desk node manage-users.js add-admin meera 'a-long-password'
STORAGE_DIR=/var/lib/claims-desk node manage-users.js passwd admin 'new-long-password'
```

With Docker: `docker exec claims-desk node manage-users.js list` (the container already has `STORAGE_DIR=/data`).

## Updating to a new version

Replace `server.js` and the `public` folder (keep the storage folder untouched), then restart: `sudo systemctl restart claims-desk` or `docker compose up -d --build`.

## Limits to know about

- Data is kept in a JSON file in memory and on disk. This suits a demo, a college project or a small team (hundreds of claims). For thousands of customers, move the storage to a database such as PostgreSQL.
- Photos are stored inside the data file, so it grows with every claim. Sessions are kept in memory, so users sign in again after a restart.
- The AI photo check is a simple on-device check, not a trained model, and approval documents are demo documents. Do not use them as real insurance policies.

## Troubleshooting

| Problem | Fix |
|---|---|
| Page opens but sign-in says "Please sign in again" every time | Make sure your proxy passes the `Authorization` header (the nginx and Caddy files here do) |
| "Request too large" when filing a claim | Raise the proxy's body limit (`client_max_body_size 45m;` in nginx) |
| Data disappeared after a redeploy | The disk is temporary. Add a persistent volume and set `STORAGE_DIR` to it |
| Cannot reach the site from another device | Check the firewall allows the port, and that `HOST` is `0.0.0.0` (or use the proxy) |
| Locked out of admin | Run `manage-users.js passwd <admin> <new password>` on the server |
