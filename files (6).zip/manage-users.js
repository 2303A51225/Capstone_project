/* Manage Claims Desk logins from the command line (works while the server is running).
   node manage-users.js list
   node manage-users.js add-admin    <username> <password>
   node manage-users.js add-customer <username> <password>
   node manage-users.js passwd       <username> <new password>
   node manage-users.js remove       <username>                                          */
'use strict';
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const STORE = process.env.STORAGE_DIR ? path.resolve(process.env.STORAGE_DIR) : path.join(__dirname, 'storage');
const FILE = path.join(STORE, 'users.json');
fs.mkdirSync(STORE, { recursive: true });
let users = {}; try { users = JSON.parse(fs.readFileSync(FILE, 'utf8')) } catch (e) { }
const save = () => { fs.writeFileSync(FILE + '.tmp', JSON.stringify(users, null, 2)); fs.renameSync(FILE + '.tmp', FILE) };
const hash = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const [cmd, name0, pw] = process.argv.slice(2), name = (name0 || '').toLowerCase();
const fail = m => { console.error(m); process.exit(1) };
function put(role) {
  if (!/^[a-z0-9._-]{3,32}$/.test(name)) fail('Username must be 3 to 32 letters, numbers, dot, dash or underscore.');
  if (!pw || pw.length < 8) fail('Password must be at least 8 characters.');
  if (users[name]) fail('That username already exists. Use "passwd" to change its password.');
  const salt = crypto.randomBytes(16).toString('hex');
  users[name] = { uid: 'u' + crypto.randomBytes(8).toString('hex'), role, salt, hash: hash(pw, salt), created: Date.now() }; save();
  console.log('Added ' + role + ' "' + name + '".');
}
if (cmd === 'list') Object.entries(users).forEach(([n, u]) => console.log(u.role.padEnd(9) + n));
else if (cmd === 'add-admin') put('admin');
else if (cmd === 'add-customer') put('customer');
else if (cmd === 'passwd') {
  if (!users[name]) fail('No such user.'); if (!pw || pw.length < 8) fail('Password must be at least 8 characters.');
  const salt = crypto.randomBytes(16).toString('hex'); users[name].salt = salt; users[name].hash = hash(pw, salt); save(); console.log('Password changed for "' + name + '".');
} else if (cmd === 'remove') { if (!users[name]) fail('No such user.'); delete users[name]; save(); console.log('Removed "' + name + '".') }
else console.log(fs.readFileSync(__filename, 'utf8').split('*/')[0].replace('/*', '').trim());
